#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hashmap.h"
#include "query.h"


int main(void)
{ 
  int bucketAmount;

  printf("Enter number of buckets: \n");

  scanf("%d", &bucketAmount);

  //Hashtable initialized

  struct hashmap* hm = hm_create(bucketAmount);

  //Hashtable created

  hm = training(hm);

  char userOption; 

  // Begin user input
  printf("Enter S to search or X to Exit: ");

  scanf(" %c", &userOption);

  //Query can be 999 chars long
  char* query = malloc(sizeof(char) * 999);
  
  while(userOption == 's' || userOption == 'S'){
    printf("Enter your search query: \n");
    scanf(" %[^\n]%*c",query);
    //Read the search query and return a ranking.
    readQuery(query, hm);
    printf("Enter S to search or X to Exit: ");
    scanf(" %c", &userOption);
  }
  
  printf("\nEXITING PROGRAM\n");

  return 0;
}
