#include "hashmap.h"
#include "query.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

struct hashmap* training(struct hashmap* hm){
  //Open our files so that we can train them
  FILE *fileName1 = fopen("D1.txt", "r");
  FILE *fileName2 = fopen("D2.txt", "r");
  FILE *fileName3 = fopen("D3.txt", "r");

  //I assumed words were no longer than  100 characters
  char* word = (char*) malloc(sizeof(char) * 100);

  //Put all of the files in our hashmap 
  printf("training first document\n");
  while(fscanf(fileName1, " %99s", word) == 1)
  {
    hm_put(hm, word, "D1.txt", 1);
    word = (char*) malloc(sizeof(char) * 100);
  }
  printf("training second document\n");
  while(fscanf(fileName2, " %99s", word) == 1)
  {
    hm_put(hm, word, "D2.txt", 1);
    word = (char*) malloc(sizeof(char) * 100);
  }
  printf("training third document \n\n");
  while(fscanf(fileName3, " %99s", word) == 1)
  {
    hm_put(hm, word, "D3.txt", 1);
    word = (char*) malloc(sizeof(char) * 100);
  }

  //Close the the input files
  fclose(fileName1);
  fclose(fileName2);
  fclose(fileName3);

  return hm;
 }

 double* rank(struct hashmap* hm, char* word){

  //weight list is malloced for 3 documents
  double* weightList = malloc(sizeof(double) * 3);

  //Get the term frequency of each document from the word passed in 
  int tf1 = hm_get(hm,word,"D1.txt");
  int tf2 = hm_get(hm,word,"D2.txt");
  int tf3 = hm_get(hm,word,"D3.txt");

  double docFrequency = 0;
  //if a word is found in a document, add one to document frequency, hakum I can type 
  if(hm_get(hm,word, "D1.txt") != 0 ){
      docFrequency++;  
  }
  if(hm_get(hm,word, "D2.txt") != 0 ){
      docFrequency++;
  }
  if(hm_get(hm,word, "D3.txt") != 0){
      docFrequency++;
  }
  //If the word doesn't appear in any of the files, set docFrequency to 1.0 or else we get nan after our idf calculation
  if(docFrequency == 0){
    docFrequency = 1.0;
  }
  //calculate the inverse document frequency of the word
  double idf = log10(3.0/docFrequency);

  //calculates the weighting of each document for the given word
  double weight1 = idf * tf1;
  double weight2 = idf * tf2;
  double weight3 = idf * tf3;

  //put the weights into an array so we can return the weightings of each document in one return statement.
  weightList[0] = weight1;
  weightList[1] = weight2;
  weightList[2] = weight3;

  return weightList;

 }

void readQuery(char* query, struct hashmap* hm){
  char * indivString;
  //Split the search query into individual words
  indivString = strtok(query," ,.-");
  //Declare document weightings
  double d1 = 0;
  double d2 = 0;
  double d3 = 0;
  //While there are still words to search in our query
  while (indivString != NULL){
    //make an array of doubles that hold the idf of the word
    double* word = rank(hm, indivString);
    //set each document to the idf of the document from ranking the word
    d1 = d1 + word[0];
    d2 = d2 + word[1];
    d3 = d3 + word[2];
    //Move onto the next word
    indivString = strtok (NULL, " ,.-");
  }
  //we need a temp variable to order the idfs
  printf("Search Query Rankings: \n");
  //If on stays 0, we know the search query isn't in any of the docs.
  int on = 0;
  //Calculate the first ranked document
  int rank = 1;
  if(d3>d2 && d3>d1 && d3>0){
    printf("rank %d  File3: %f\n",rank, d3);
    on = 1;
  }
  if(d2>d1 && d2>d3 && d2>0){
   printf("rank %d  File2: %f\n",rank, d2);
    on = 1;
  }
  if(d1>d3 && d1>d2 && d1>0){
    printf("rank %d  File1: %f\n",rank, d1);
    on = 1;
  }

  //Calculate the second ranked document
  rank = 2;

  if((d3>d2 && d3<d1 && d3>0) || (d3<d2 && d3>d1 && d3>0)){
    printf("rank %d  File3: %f\n",rank, d3);
    on = 1;
  }
  if((d2>d1 && d2<d3 && d2>0) || (d2<d1 && d2>d3 && d2>0)){
   printf("rank %d  File2: %f\n",rank, d2);
    on = 1;
  }
  if((d1>d2 && d1<d3 && d1>0) || (d1<d2 && d1>d3 && d1>0)){
    printf("rank %d  File1: %f\n",rank, d1);
    on = 1;
  }

  rank = 3;
  //Calculate the third ranked document
  if(d3<d2 && d3<d1 && d3>0){
    printf("rank %d  File3: %f\n",rank, d3);
    on = 1;
  }
  if(d2<d1 && d2<d3 && d2>0){
   printf("rank %d  File2: %f\n",rank, d2);
    on = 1;
  }
  if(d1<d3 && d1<d2 && d1>0){
    printf("rank %d  File1: %f\n",rank, d1);
    on = 1;
  }
  //If no words in the search query are in the documents, no match was found.
  if(on == 0){
    printf("No Document Match\n");
  }

}
