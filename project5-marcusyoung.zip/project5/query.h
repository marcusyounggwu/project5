#ifndef QUERY_H
#define QUERY_H

#include "hashmap.h"

//Function definitions of training, stop_word, rank, and readQuery

struct hashmap* training(struct hashmap* hm);

void stop_word(struct hashmap* hm);
double* rank(struct hashmap* hm, char* word);
void readQuery(char* query, struct hashmap* hm);

#endif
