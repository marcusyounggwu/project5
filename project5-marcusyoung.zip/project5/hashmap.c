#include "hashmap.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



struct hashmap* hm_create(int num_buckets){
  //Allocated memory for the hashmap
  struct hashmap* newMap = (struct hashmap*) malloc(sizeof(struct hashmap));
  newMap->map = (struct llnode**) malloc(sizeof(struct llnode*)* num_buckets);
  //Set each index to NULL to be sure we know what an empty bucket is
  for( int i=0; i< num_buckets; i++)
  {
    newMap->map[i]= NULL;
  }
  newMap->num_buckets = num_buckets;
  newMap->num_elements= 0;
  return newMap;
  
}

void hm_remove(struct hashmap* hm, char* word, char* document_id){
  //need a previous and current pointer.
  struct llnode *iter1;
  struct llnode *iter2;

  int key = hash(hm, word, document_id);
  //points to head of bucket, and next node
  iter1 = hm->map[key];
  iter2 = iter1->next;
 
  if(strcmp(iter1->word, word)== 0 && strcmp(iter1->document_id, document_id)== 0){
    //if found what we want, set prev to next of next and free next
    hm->map[key] = iter2;
    free(iter1);
    return;
  }
  while(iter1->next != NULL){
    if(strcmp(iter2->word, word)== 0 && strcmp(iter2->document_id, document_id)== 0){
      //if found what we want, set prev to next of next and free next
      iter1->next = iter2->next;
      free(iter2);
      return;
    }

    //move pointers to next nodes
    iter1 = iter1->next;
    iter2 = iter2->next;
    
  }
  free(iter1);
  return;
}

int hm_get(struct hashmap* hm, char* word, char* document_id){
  struct llnode *temp;
  int key = hash(hm, word, document_id);

  //set temp to head of bucket
  temp = hm->map[key];

  //while the node word we are on is not the same as the word we want, go to the next node.
  while(strcmp(temp->word, word) != 0 || strcmp(temp->document_id, document_id) != 0){
    if(temp->next == NULL){
      //no word was found
      return 0;
    }
    else{
      //move to the next node.
      temp = temp->next;
    }
  }
  //return the number of occurences of that node.
  return temp->num_occurrences;
}

void hm_put(struct hashmap* hm, char* word, char* document_id, int num_occurrences){

  struct llnode *newNode;

  newNode = malloc(sizeof(struct llnode));
  newNode->word = word;
  newNode->document_id = document_id;
  newNode->num_occurrences = num_occurrences;
  newNode->docFrequency = 1;
  newNode->next = NULL;
  
  int key = hash(hm, word, document_id);

  struct llnode *temp = hm->map[key];

  if(temp == NULL) {
    hm->map[key] = newNode;
    return;
  }

  while(temp->next != NULL){

    if(strcmp(word, temp->word) == 0 && strcmp(document_id, temp->document_id) == 0){
      temp->num_occurrences = temp->num_occurrences + 1;
      return;
    }

    temp = temp->next;
  }
  //Checks last node too
  if(strcmp(word, temp->word) == 0 && strcmp(document_id, temp->document_id) == 0){
      temp->num_occurrences = temp->num_occurrences + 1;
      return;
    }

  temp->next = newNode;
}

void hmPrint(struct hashmap* hm){
  struct llnode *iterator;
  for(int i=0; i< hm->num_buckets; i++) {
    //Current bucket we are on
    printf("Bucket: %d\n", i+1);
    iterator = hm->map[i];
    //iterator is head of current bucket 
    if(iterator == NULL){
      //The bucket is empty
      printf("no contents\n");
    }
    while(iterator != NULL){
      //prints the node information
      printf("Word: %s   Occurences: %d  df: %d  DocID: %s\n", iterator->word, iterator->num_occurrences, iterator->docFrequency, iterator->document_id);
      iterator = iterator->next;
    }
  }
}

void hm_destroy(struct hashmap* hm){
  //need two temp variables
  struct llnode *temp1, *temp;

  for(int i=0; i< hm->num_buckets; i++){
  //temp 1 is head of node
  temp1 = hm->map[i];
    while(temp1 != NULL){
      //frees previous node, sets temp1 to next node.
      temp = temp1;
      temp1 = temp1->next;
      free(temp);
    }
  }
  //free map and hashmap
  free(hm->map);
  free(hm);
}

int hash(struct hashmap* hm, char* word, char* document_id){

  int key = 0;
  int sum = 0;

  //Hash function is the sum of word and doc id ascii vals % num buckets
  for(int i = 0; i < (int)strlen(word); i++){
    sum += word[i];
  }

  for(int i = 0; i < (int)strlen(document_id); i++){
    sum += document_id[i];
  }

  //Return key
  key = sum % hm->num_buckets;
  return key;
}
